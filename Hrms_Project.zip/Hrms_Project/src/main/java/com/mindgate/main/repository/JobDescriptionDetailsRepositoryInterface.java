package com.mindgate.main.repository;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;

import com.mindgate.main.domain.EmployeeDetails;
import com.mindgate.main.domain.JobDescriptionDetails;

public interface JobDescriptionDetailsRepositoryInterface {
	public List<JobDescriptionDetails> getAllDescription();

	public List<JobDescriptionDetails> getJobDescriptionByemployeeId(int employeeId);
	
	public boolean addJobDescription(JobDescriptionDetails jobDescriptionDetails);

	public List<JobDescriptionDetails> getJobDescriptionByProjectId(String projectId);
	
	 public boolean updateJobStatus(JobDescriptionDetails jobDescriptionDetails);
	 
	 public boolean updateRequiredCandidate(JobDescriptionDetails jobDescriptionDetails) ;
	 
	 public JobDescriptionDetails getJobDescriptionByJobId(int jobId);
	 
	 public List<JobDescriptionDetails> getAllDescriptionApproved();
	 
	public List<JobDescriptionDetails> getAllDescriptionPublish();


}
