package com.mindgate.main.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.domain.InterviewerDetails;
import com.mindgate.main.service.InterviewerDetailsServiceInterface;

@CrossOrigin("*")
@RestController
@RequestMapping("InterviewerDetailsapi")
public class InterviewerDetailsController {

	@Autowired
	private InterviewerDetailsServiceInterface InterviewerDetailsService;

	@RequestMapping(value = "addInterviewerDetails", method = RequestMethod.POST)
	public boolean addInterviewerDetails(@RequestBody InterviewerDetails interviewerDetails) {
		// TODO Auto-generated method stub
		return InterviewerDetailsService.addInterviewerDetails(interviewerDetails);
	}

	@RequestMapping(value = "getInterviewerDetails/{employee_id}", method = RequestMethod.GET)
	public List<InterviewerDetails> ViewApplicant(@PathVariable int employee_id) {

		return InterviewerDetailsService.getInterviewerDetailst(employee_id);
	}

	@RequestMapping(value = "updateInterviewDetails", method = RequestMethod.PUT)
	public boolean updateInterviewerDetails(@RequestBody InterviewerDetails interviewerDetails) {

		System.out.println(interviewerDetails);

		return InterviewerDetailsService.updateInterviewerDetails(interviewerDetails);

	}

	@RequestMapping(value = "getInterviewerObject/{interviewId}", method = RequestMethod.GET)
	public InterviewerDetails getInterviewObject(@PathVariable int interviewId) {
		System.out.println("getInterviewObject");
		return InterviewerDetailsService.getInterviewObject(interviewId);
	}
}
