package com.mindgate.main.controller;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindgate.main.service.EmailSenderService;

@CrossOrigin("*")
@RestController
@RequestMapping("sendemailapi")
public class EmailSenderController {
	

   @Autowired
	private EmailSenderService service;
	
	public void triggerMail() throws MessagingException {

	service.sendEmailWithAttachment("realajay.98@gmail.com", "This is Email Body with Attachment...", "Success","E:\\Project_DataBase\\ITComputation.pdf");
	}

}
