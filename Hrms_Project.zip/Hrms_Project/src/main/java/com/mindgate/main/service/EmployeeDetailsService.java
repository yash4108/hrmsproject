package com.mindgate.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindgate.main.domain.EmployeeDetails;
import com.mindgate.main.repository.EmployeeDetailsRepository;
import com.mindgate.main.repository.EmployeeDetailsRepositoryInterface;

@Service
public class EmployeeDetailsService implements EmployeeDetailsServiceInterface {

	@Autowired
	private EmployeeDetailsRepositoryInterface employeeDetailsRepository;

	@Override
	public EmployeeDetails getEmployeeByLoginId(int loginId) {

		return employeeDetailsRepository.getEmployeeByLoginId(loginId);
	}

	@Override
	public List<EmployeeDetails> checkEmployee(int jobId) {
		// TODO Auto-generated method stub
		return employeeDetailsRepository.checkEmployee(jobId);
	}

	@Override
	public boolean updateJobStatus(EmployeeDetails employeeDetails) {
		// TODO Auto-generated method stub
		return employeeDetailsRepository.updateJobStatus(employeeDetails);
	}

	@Override
	public boolean addEmployee(EmployeeDetails employeeDetails) {
		// TODO Auto-generated method stub
		return employeeDetailsRepository.addEmployee(employeeDetails);
	}

	@Override
	public List<EmployeeDetails> getAllEmployee() {
		System.out.println("getAllEmployee in Service");
		return employeeDetailsRepository.getAllEmployee();
	}

//	@Override
//	public EmployeeDetails checkInterviewer(int jobId) {
//		// TODO Auto-generated method stub
//		return employeeDetailsRepository.checkInterviewer(jobId);
//	}

	@Override
	public List<EmployeeDetails> checkInterviewer(int jobId) {
		// TODO Auto-generated method stub
		return employeeDetailsRepository.checkInterviewer(jobId);
	}

}
