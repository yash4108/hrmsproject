package com.mindgate.main.repository;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.InterviewerDetails;

@Repository
public class InterviewerDetailsRepository implements InterviewerDetailsRepositoryInterface {

	private final static String INSERT_INTERVIWER_DETAILS = "insert into interviewer_details values(interviewer_table_sequence_series.NEXTVAL,?,?,?,?,?,?)";
	private final static String GET_INTERVIWER_DETAILS = "select interview_id,applicant_id,employee_id, status,round_1,round_2,round_3 from interviewer_details where employee_id=? and status='Shortlisted'";
	private final static String PUT_INTERVIWER_DETAILS = "UPDATE interviewer_details SET status = ?, round_1 =?,round_2 = ?,round_3=?  WHERE  applicant_id = ?";
	private static final String GET_INTERVIEWER_OBJECT="  select * from interviewer_details where interview_id=?";

	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public boolean addInterviewerDetails(InterviewerDetails interviewerDetails) {
		// TODO Auto-generated method stub
		Object[] param = { interviewerDetails.getApplicantDetails().getApplicantId(),
				interviewerDetails.getEmployeeDetails().getEmployeeId(), interviewerDetails.getStatus(),
				interviewerDetails.getRound1(), interviewerDetails.getRound2(), interviewerDetails.getRound3() };
		int result = jdbcTemplate.update(INSERT_INTERVIWER_DETAILS, param);
		if (result > 0) {
			System.out.println("insert success");
			return true;
		}
		return false;
	}

	@Override
	public List<InterviewerDetails> getInterviewerDetailst(int employee_id) {
		return jdbcTemplate.query(GET_INTERVIWER_DETAILS, new InterviewerDetailsRowMapper(), employee_id);

	}

	@Override
	public boolean updateInterviewerDetails(InterviewerDetails interviewerDetails) {
		// TODO Auto-generated method stub
		System.out.println(interviewerDetails);
		Object[] params= {interviewerDetails.getStatus(), interviewerDetails.getRound1(), interviewerDetails.getRound2(),interviewerDetails.getRound3(), interviewerDetails.getApplicantDetails().getApplicantId()};
		int result = jdbcTemplate.update(PUT_INTERVIWER_DETAILS, params);
		if (result > 0)
			return true;
		return false;
	}
	
	
	
	public InterviewerDetails getInterviewObject(int interviewId) {
		
		
		return jdbcTemplate.queryForObject(GET_INTERVIEWER_OBJECT, new InterviewerDetailsRowMapper(), interviewId);
	}
}




