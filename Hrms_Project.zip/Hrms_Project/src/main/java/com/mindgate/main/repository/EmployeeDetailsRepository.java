package com.mindgate.main.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.mindgate.main.domain.EmployeeDetails;
import com.mindgate.main.domain.JobDescriptionDetails;
import com.mindgate.main.domain.LoginDetails;
import com.mindgate.main.domain.ProjectDetails;

@Repository
public class EmployeeDetailsRepository implements EmployeeDetailsRepositoryInterface {

	private final static String GET_EMPLOYEE_BY_LOGIN_ID = "SELECT * FROM EMPLOYEE_DETAILS WHERE LOGIN_ID=?";
	private final static String CHECK_EMPLOYEE_LIST = "select * from employee_details where project_id = 103 and skill_1 = (select skill_1 from job_description_details where job_id =?) and skill_2 = (select skill_2 from job_description_details where job_id = ?) and skill_3 = (select skill_3 from job_description_details where job_id =?)";
	private final static String UPDATE_PROJECT_ID_BY_EMPLOYEE_ID = "update Employee_details SET project_Id=?,mgr=?,status=? where employee_id=?";
	private final static String INSERT_EMPLOYEE = "insert into employee_details values(Employee_Id_sequence_Series.NEXTVAL,?,?,?,?,?,?,?,?,?,?)";
	private final static String GET_ALL_EMPLOYEES = "Select * from employee_details";
    private final static String MATCH_INTERVIEWEE_SKILLS="select * from employee_details where designation='Interviewer' and skill_1 = (select skill_1 from job_description_details where job_id =?) and skill_2 = (select skill_2 from job_description_details where job_id = ?) and skill_3 = (select skill_3 from job_description_details where job_id =?)";
	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public EmployeeDetails getEmployeeByLoginId(int loginId) {
		EmployeeDetails employeeDetails = jdbcTemplate.queryForObject(GET_EMPLOYEE_BY_LOGIN_ID,
				new EmployeeDetailsRowMapper(), loginId);

		return employeeDetails;
	}

	@Override
	public List<EmployeeDetails> checkEmployee(int jobId) {

		return jdbcTemplate.query(CHECK_EMPLOYEE_LIST, new EmployeeDetailsRowMapper(), jobId, jobId, jobId);

	}

	@Override
	public boolean updateJobStatus(EmployeeDetails employeeDetails) {
		Object[] params = { employeeDetails.getProjectDetails().getProjectId(), employeeDetails.getMGR(),
				employeeDetails.getStatus(), employeeDetails.getEmployeeId() };

		int result = jdbcTemplate.update(UPDATE_PROJECT_ID_BY_EMPLOYEE_ID, params);
		if (result > 0) {
			return true;

		}
		return false;
	}

	@Override
	public boolean addEmployee(EmployeeDetails employeeDetails) {
		Object[] params = { employeeDetails.getEname(), employeeDetails.getSalary(),
				employeeDetails.getProjectDetails().getProjectId(), employeeDetails.getDesignation(),
				employeeDetails.getLoginDetails().getLoginId(), employeeDetails.getMGR(), employeeDetails.getSkill1(),
				employeeDetails.getSkill2(), employeeDetails.getSkill3(), employeeDetails.getStatus() };
		int result = jdbcTemplate.update(INSERT_EMPLOYEE, params);
		if (result > 0)
			return true;
		return false;
	}

	@Override
	public List<EmployeeDetails> getAllEmployee() {
		System.out.println("getAllEmployee in Repository");

		return jdbcTemplate.query(GET_ALL_EMPLOYEES, new EmployeeDetailsRowMapper());
	}

//	@Override
//	public EmployeeDetails checkInterviewer(int jobId) {
//
//		return jdbcTemplate.queryForObject(MATCH_INTERVIEWEE_SKILLS, new EmployeeDetailsRowMapper(),jobId,jobId,jobId);
//
//	}

	@Override
	public List<EmployeeDetails> checkInterviewer(int jobId) {
		// TODO Auto-generated method stub
		
		return jdbcTemplate.query(MATCH_INTERVIEWEE_SKILLS, new EmployeeDetailsRowMapper(),jobId,jobId,jobId);
	}
	
}
